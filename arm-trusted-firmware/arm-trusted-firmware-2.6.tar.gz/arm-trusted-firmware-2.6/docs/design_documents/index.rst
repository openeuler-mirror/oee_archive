Design Documents
================

.. toctree::
   :maxdepth: 1
   :caption: Contents
   :numbered:

   cmake_framework
   measured_boot_poc

--------------

*Copyright (c) 2020, Arm Limited and Contributors. All rights reserved.*
