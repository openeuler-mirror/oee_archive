
"""This module has a __version__ that requires runtime interpretation"""

__version__ = ".".join(["1", "2", "3"])
