"""This module has a __version__ that requires a relative import"""

from ._version import __version__
