flit_core
---------

This provides a PEP 517 build backend for packages using Flit.
The only public interface is the API specified by PEP 517, at ``flit_core.buildapi``.

