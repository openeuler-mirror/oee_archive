Multitarget Tracker
===================

This code is mostly copied from the (MultitargetTracker)[https://github.com/Smorodov/Multitarget-tracker].
It is utilized for the *CostmapToDynamicObstacles* plugin.

The *MultitargetTracker* is licensed under (GNU GPLv3)[https://www.gnu.org/licenses/gpl-3.0.txt].
The package itself depends on other third party packages with different licenses (refer to the package repository).

TODO: Include the whole package as external CMake project.



